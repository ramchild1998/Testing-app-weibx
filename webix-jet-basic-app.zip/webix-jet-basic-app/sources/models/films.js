export function getData(){
	return webix.ajax("../../data/film_data.js");
}