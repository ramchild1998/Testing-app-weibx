export function getData(){
	return webix.ajax("../../data/user_data.js");
}
