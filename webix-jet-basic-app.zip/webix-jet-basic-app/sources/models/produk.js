export function getData(){
	return webix.ajax("../../data/product_data.js");
}
