[
	{ "id":1, "nama":"Ramadiansyah", "umur":23, "negara":"Indonesia"},
	{ "id":2, "nama":"Nina Brown", "umur":32, "negara":"Germany"},
	{ "id":3, "nama":"Kevin Sallivan", "umur":21, "negara":"Canada"},
	{ "id":4, "nama":"Sergey Petrov", "umur":24, "negara":"Russia"},
	{ "id":5, "nama":"Mina Leen", "umur":40, "negara":"China"},
	{ "id":6, "nama":"Sam White", "umur":26, "negara":"USA"},
	{ "id":7, "nama":"Peter Olsten", "umur":40, "negara":"France"},
	{ "id":8, "nama":"Lina Rein", "umur":30, "negara":"Germany"},
	{ "id":9, "nama":"Many Cute", "umur":22, "negara":"Canada"},
	{ "id":10, "nama":"Andrew Wein", "umur":27, "negara":"Italy"},
	{ "id":11, "nama":"Paolo Sanders", "umur":40, "negara":"Spain"},
	{ "id":12, "nama":"Tanya Krieg", "umur":28, "negara":"Germany"}
]
